class Account {
    constructor(accountId, balance) {
        this.accountId = accountId;
        this.balance = balance;
    }

    deposit(amount) {
        this.balance += amount;
    }

    withdraw(amount) {
        if (this.balance >= amount) {
            this.balance -= amount;
        } else {
            alert('Insufficient balance');
        }
    }

    getDetails() {
        return `Account ID: ${this.accountId}, Balance: ${this.balance}`;
    }
}

class Transaction {
    constructor(transactionId, date, type, amount, accountId) {
        this.transactionId = transactionId;
        this.date = date;
        this.type = type;
        this.amount = amount;
        this.accountId = accountId;
    }
}

class BankSystem {
    constructor() {
        this.accounts = [];
        this.transactions = [];
    }

    createAccount(accountId, initialBalance) {
        const account = new Account(accountId, initialBalance);
        this.accounts.push(account);
        this.addTransaction('create', 0, accountId);
    }

    deposit(accountId, amount) {
        const account = this.findAccount(accountId);
        if (account) {
            account.deposit(amount);
            this.addTransaction('deposit', amount, accountId);
        } else {
            alert('Account not found');
        }
    }

    withdraw(accountId, amount) {
        const account = this.findAccount(accountId);
        if (account) {
            account.withdraw(amount);
            this.addTransaction('withdraw', amount, accountId);
        } else {
            alert('Account not found');
        }
    }

    findAccount(accountId) {
        return this.accounts.find(account => account.accountId === accountId);
    }

    addTransaction(type, amount, accountId) {
        const transactionId = this.transactions.length + 1;
        const date = new Date();
        const transaction = new Transaction(transactionId, date, type, amount, accountId);
        this.transactions.push(transaction);
        this.displayTransaction(transaction);
    }

    displayTransaction(transaction) {
        const transactionList = document.getElementById('transaction-list');
        const listItem = document.createElement('li');
        listItem.textContent = `Transaction ID: ${transaction.transactionId}, Date: ${transaction.date.toLocaleString()}, Type: ${transaction.type}, Amount: ${transaction.amount}, Account ID: ${transaction.accountId}`;
        transactionList.appendChild(listItem);
    }

    displayAccountDetails(account) {
        const accountDetails = document.getElementById('account-details');
        accountDetails.textContent = account.getDetails();
    }

    listAllAccounts() {
        const accountsList = document.getElementById('accounts-list');
        accountsList.innerHTML = '';
        this.accounts.forEach(account => {
            const listItem = document.createElement('li');
            listItem.textContent = account.getDetails();
            accountsList.appendChild(listItem);
        });
    }
}

const bankSystem = new BankSystem();

document.getElementById('create-account-form').addEventListener('submit', function(event) {
    event.preventDefault();
    const accountId = parseInt(document.getElementById('account-id').value);
    const initialBalance = parseInt(document.getElementById('initial-balance').value);
    bankSystem.createAccount(accountId, initialBalance);
    this.reset();
});

document.getElementById('deposit-form').addEventListener('submit', function(event) {
    event.preventDefault();
    const accountId = parseInt(document.getElementById('deposit-account-id').value);
    const amount = parseInt(document.getElementById('deposit-amount').value);
    bankSystem.deposit(accountId, amount);
    this.reset();
});

document.getElementById('withdraw-form').addEventListener('submit', function(event) {
    event.preventDefault();
    const accountId = parseInt(document.getElementById('withdraw-account-id').value);
    const amount = parseInt(document.getElementById('withdraw-amount').value);
    bankSystem.withdraw(accountId, amount);
    this.reset();
});

document.getElementById('view-account-form').addEventListener('submit', function(event) {
    event.preventDefault();
    const accountId = parseInt(document.getElementById('view-account-id').value);
    const account = bankSystem.findAccount(accountId);
    if (account) {
        bankSystem.displayAccountDetails(account);
    } else {
        alert('Account not found');
    }
});

document.getElementById('list-accounts-button').addEventListener('click', function() {
    bankSystem.listAllAccounts();
});