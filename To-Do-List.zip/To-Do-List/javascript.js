const taskInput = document.getElementById('new-task');
    const addTaskButton = document.getElementById('add-task');
    const todoList = document.getElementById('todo-list');

    function createTaskElement(taskText) {
      const listItem = document.createElement('li');
      listItem.className = 'todo-item';

      const inputField = document.createElement('input');
      inputField.type = 'text';
      inputField.value = taskText;
      inputField.disabled = true;

      const actions = document.createElement('div');
      actions.className = 'todo-actions';

      const editButton = document.createElement('button');
      editButton.textContent = 'Edit';
      editButton.className = 'edit';
      
      const deleteButton = document.createElement('button');
      deleteButton.textContent = 'Delete';
      deleteButton.className = 'delete';

      actions.appendChild(editButton);
      actions.appendChild(deleteButton);

      listItem.appendChild(inputField);
      listItem.appendChild(actions);

      editButton.addEventListener('click', () => {
        if (editButton.textContent === 'Edit') {
          inputField.disabled = false;
          inputField.focus();
          editButton.textContent = 'update';
        } else {
          inputField.disabled = true;
          editButton.textContent = 'Edit';
        }
      });

      deleteButton.addEventListener('click', () => {
        todoList.removeChild(listItem);
      });

      return listItem;
    }

    addTaskButton.addEventListener('click', () => {
      const taskText = taskInput.value.trim();
      if (taskText) {
        const taskElement = createTaskElement(taskText);
        todoList.appendChild(taskElement);
        taskInput.value = '';
      }
    });

    taskInput.addEventListener('keypress', (e) => {
      if (e.key === 'Enter') {
        addTaskButton.click();
      }
    });